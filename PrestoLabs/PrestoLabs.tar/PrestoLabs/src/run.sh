make run Rule=Normal
make run

